# -*- coding: utf-8 -*-

__title__ = 'r6sapi'
__author__ = 'billyoyo'
__license__ = 'MIT'
__copyright__ = 'Copyright 2016-2017 billyoyo'
__version__ = '0.1.0'

from .r6sapi import *

