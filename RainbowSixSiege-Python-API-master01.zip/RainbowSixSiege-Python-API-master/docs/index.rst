.. r6sapi.py documentation master file, created by
   sphinx-quickstart on Sat Dec 31 12:48:36 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to r6sapi.py's documentation!
=====================================

Contents
--------

.. toctree::
   :maxdepth: 2
   
   gettingstarted
   api
   how


Indices and tables
------------------

* :ref:`genindex`
* :ref:`search`
